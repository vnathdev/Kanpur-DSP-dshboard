# Kanpur Grievance Dashboard (NCAP DSP)

Standalone Streamlit dashboard for Kanpur Nagar Nigam air-quality grievance
data. Portal exports are uploaded through the app; category definitions are
read live from the published definitions sheet.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then upload a **Complaints List** export (`.xlsx` or `.csv`) in the sidebar.

## Files

| File | Purpose |
|---|---|
| `app.py` | Streamlit UI, filters, KPIs, charts |
| `kanpur_normalize.py` | Export parsing, category derivation, validation |
| `requirements.txt` | Pinned minimums |

## How categories work

The export's own `Category` column is **not** used for analysis. Kanpur has
three analysis categories — Sanitation, Engineering and **Malba** — but the
portal only emits two, reporting Malba tickets as Engineering. The analysis
category is therefore derived from `Sub Category` via the definitions sheet:

- `Category` — derived, used everywhere in the dashboard
- `category_raw` — as the portal sent it, kept for audit
- `recategorised` — True where the two differ (see the reclassified-tickets panel)

Sub-category matching ignores case, whitespace and punctuation, so
`Removal of Debris` in the export matches `Removal of debris` in the sheet.
Anything not in the sheet lands in `Unmapped` and is reported in the
data-quality panel rather than silently absorbed.

To add a sub-category, add a row to the definitions sheet — no code change.
The sheet is cached for one hour.

## Export quirks handled

- Row 1 is a title banner; the real header is row 2
- A phantom first column whose header is a non-breaking space
- `Zone 4 & Mcrobertganj-15` → zone / ward name / ward number
- `Er. Minakshi Agrawal & 9411062529` → name / mobile, splitting on the last
  `&` so names containing `&` survive
- `17 Aug 2026 10:35 AM` datetime format
- Blank `Date of Closure` on Pending and Rejected tickets

## Known limits

- Each upload is a standalone snapshot; there is no cross-upload history, so
  month-on-month trends need a cumulative export
- `Median age of pending` is measured from the latest ticket in the uploaded
  file, not from today
- If the definitions sheet is unreachable, a built-in snapshot is used and a
  warning is shown; update `FALLBACK_CATEGORY_ROWS` if the sheet changes
