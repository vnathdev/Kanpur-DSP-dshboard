"""
Kanpur grievance dump normalisation.

Two responsibilities, deliberately separated:

  load_definitions()  -- pulls the three master tabs from the published sheet
  normalize_dump()    -- turns a raw portal export into a tidy analysis frame

The analysis category is DERIVED from `Sub Category` via the master table.
The dump's own `Category` column is preserved as `category_raw` for audit but
is never used for analysis -- Malba tickets arrive labelled "Engineering".
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field

import pandas as pd

# ---------------------------------------------------------------- definitions

SHEET_PUB = (
    "https://docs.google.com/spreadsheets/d/e/"
    "2PACX-1vTF0TbAXN6O1-Te6vCMlE9r-BbKb7Z-TrFVm2FMPx-ioorWRJFXM4mjqSy-VbxlSh4nCBlF6PtnMbyv"
    "/pub?gid={gid}&single=true&output=csv"
)

GID_COLUMNS = 0
GID_STATUS = 907869929
GID_CATEGORY = 553718957

# Raw portal sub-category string -> master sub-category label.
# Empty as of 2026-09-09: the master sheet now carries the portal's exact
# wording, so `_norm_key` alone resolves every row. Only add an entry here if
# the portal changes a label and the sheet can't be updated to match.
SUBCATEGORY_ALIASES: dict[str, str] = {}

EXPECTED_COLUMNS = [
    "Comp. No.", "Category", "Sub Category", "Zone & Ward",
    "Complainer Name & Mob. No.", "Concern Person Name & Mob. No.",
    "Date & Time", "Date of Closure", "Description", "Status",
]

DATE_FORMAT = "%d %b %Y %I:%M %p"


@dataclass
class Definitions:
    """Master tables from the definitions sheet."""
    columns: list[str]
    statuses: list[str]
    subcategory_to_category: dict[str, str]   # normalised key -> category
    subcategory_label: dict[str, str]         # normalised key -> master label

    @property
    def categories(self) -> list[str]:
        seen: list[str] = []
        for cat in self.subcategory_to_category.values():
            if cat not in seen:
                seen.append(cat)
        return seen


def _norm_key(value: object) -> str:
    """Aggressive key for joining category strings.

    Casefolds, strips accents, and drops every non-alphanumeric character, so
    'Removal of Debris' and 'Removal of debris' collide -- but genuinely
    different wording still does not, which is the point.
    """
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return ""
    text = unicodedata.normalize("NFKD", str(value))
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return re.sub(r"[^a-z0-9]+", "", text.casefold())


def load_definitions(sheet_pub: str = SHEET_PUB) -> Definitions:
    columns = (
        pd.read_csv(sheet_pub.format(gid=GID_COLUMNS))
        .iloc[:, 0].dropna().astype(str).str.strip().tolist()
    )
    statuses = (
        pd.read_csv(sheet_pub.format(gid=GID_STATUS))
        .iloc[:, 0].dropna().astype(str).str.strip().tolist()
    )

    cat = pd.read_csv(sheet_pub.format(gid=GID_CATEGORY))
    cat.columns = [str(c).strip() for c in cat.columns]
    cat = cat.rename(columns={"Sub category": "Sub Category"})
    # Category is merged-cell style: only the first row of each block is filled.
    cat["Category"] = cat["Category"].ffill()
    cat = cat.dropna(subset=["Sub Category"])
    cat["Sub Category"] = cat["Sub Category"].astype(str).str.strip()
    cat = cat[cat["Sub Category"] != ""]

    sub_to_cat, sub_label = {}, {}
    for _, row in cat.iterrows():
        key = _norm_key(row["Sub Category"])
        sub_to_cat[key] = str(row["Category"]).strip()
        sub_label[key] = row["Sub Category"]

    return Definitions(columns, statuses, sub_to_cat, sub_label)


# ------------------------------------------------------------------ splitting

_MOBILE_RE = re.compile(r"^\+?\d[\d\s\-]{7,}$")


def split_name_mobile(value: object) -> tuple[str | None, str | None]:
    """'Er. Minakshi Agrawal & 9411062529' -> ('Er. Minakshi Agrawal', '9411062529').

    Splits on the LAST '&' and only accepts the right side as a mobile number
    if it actually looks like one -- so a name containing '&' stays intact and
    a missing number yields (name, None) rather than a mangled pair.
    """
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None, None
    text = re.sub(r"\s+", " ", str(value)).strip()
    if not text:
        return None, None
    if "&" not in text:
        return text or None, None
    left, right = text.rsplit("&", 1)
    left, right = left.strip(), right.strip()
    if _MOBILE_RE.match(right):
        return (left or None), re.sub(r"[\s\-]", "", right)
    return text, None


def split_zone_ward(value: object) -> tuple[str | None, str | None, int | None]:
    """'Zone 4 & Mcrobertganj-15' -> ('Zone 4', 'Mcrobertganj', 15).

    Ward number is taken from the LAST hyphen so hyphenated ward names survive.
    """
    if value is None or (isinstance(value, float) and pd.isna(value)):
        return None, None, None
    text = re.sub(r"\s+", " ", str(value)).strip()
    if not text:
        return None, None, None

    if "&" in text:
        zone, ward = (part.strip() for part in text.split("&", 1))
    elif re.match(r"(?i)^zone\b", text):
        zone, ward = text, None      # 'Zone 5' with no ward attached
    else:
        zone, ward = None, text

    ward_no = None
    if ward and "-" in ward:
        head, tail = ward.rsplit("-", 1)
        if tail.strip().isdigit():
            ward, ward_no = head.strip(), int(tail.strip())

    return (zone or None), (ward or None), ward_no


# ---------------------------------------------------------------- main loader

@dataclass
class LoadReport:
    """Everything that needs a human decision, surfaced rather than swallowed."""
    rows_in: int = 0
    rows_out: int = 0
    unmapped_subcategories: dict[str, int] = field(default_factory=dict)
    unknown_statuses: dict[str, int] = field(default_factory=dict)
    unparsed_opened: int = 0
    unparsed_closed: int = 0
    closed_before_opened: int = 0
    missing_columns: list[str] = field(default_factory=list)

    @property
    def is_clean(self) -> bool:
        return not (
            self.unmapped_subcategories
            or self.unknown_statuses
            or self.missing_columns
            or self.unparsed_opened
            or self.closed_before_opened
        )

    def render(self) -> str:
        lines = [f"{self.rows_in} rows in, {self.rows_out} rows out"]
        if self.missing_columns:
            lines.append(f"MISSING COLUMNS: {', '.join(self.missing_columns)}")
        for label, mapping in (
            ("UNMAPPED sub-category", self.unmapped_subcategories),
            ("UNKNOWN status", self.unknown_statuses),
        ):
            for value, count in sorted(mapping.items(), key=lambda kv: -kv[1]):
                lines.append(f"{label}: {value!r} ({count} rows)")
        if self.unparsed_opened:
            lines.append(f"unparseable 'Date & Time': {self.unparsed_opened}")
        if self.unparsed_closed:
            lines.append(
                f"blank/unparseable 'Date of Closure': {self.unparsed_closed} "
                "(expected for Pending)"
            )
        if self.closed_before_opened:
            lines.append(f"closure BEFORE opening: {self.closed_before_opened}")
        if self.is_clean:
            lines.append("clean")
        return "\n".join(lines)


def read_raw(path_or_url: str) -> pd.DataFrame:
    """Read a portal export, stripping the banner row and the phantom column.

    Row 1 of the export is 'Complaints List ::Online Services'; the real header
    is row 2, whose first cell is a non-breaking space above an empty column.
    """
    if str(path_or_url).lower().endswith((".xlsx", ".xlsm", ".xls")):
        df = pd.read_excel(path_or_url, header=1)
    else:
        df = pd.read_csv(path_or_url, header=1)

    df.columns = [
        re.sub(r"\s+", " ", str(c).replace("\xa0", " ")).strip()
        for c in df.columns
    ]
    # Drop the phantom leading column and any all-empty trailing columns.
    df = df.loc[:, [c for c in df.columns if c and not c.startswith("Unnamed")]]
    return df.dropna(how="all")


def read_upload(data: bytes, filename: str) -> pd.DataFrame:
    """Same as read_raw, but for an in-memory upload (Streamlit file_uploader)."""
    import io
    buf = io.BytesIO(data)
    if filename.lower().endswith((".xlsx", ".xlsm", ".xls")):
        df = pd.read_excel(buf, header=1)
    else:
        df = pd.read_csv(buf, header=1)
    df.columns = [
        re.sub(r"\s+", " ", str(c).replace("\xa0", " ")).strip()
        for c in df.columns
    ]
    df = df.loc[:, [c for c in df.columns if c and not c.startswith("Unnamed")]]
    return df.dropna(how="all")


# Snapshot of the master tables as of 2026-09-09, used only if the published
# sheet is unreachable. Keep in sync with the sheet; the app flags when it
# falls back to this.
FALLBACK_CATEGORY_ROWS = [
    ("Sanitation", "Burning of garbage in open space"),
    ("Sanitation", "Dustbin not cleaned"),
    ("Sanitation", "Garbage not cleaned"),
    ("Sanitation", "Sweeping not done"),
    ("Engineering", "Pot hole fill up/Repairs to the damage surface"),
    ("Engineering", "Disposal of removed silt from the road"),
    ("Malba", "Removal of debris"),
]
FALLBACK_STATUSES = ["Pending", "Rejected", "Completed"]


def fallback_definitions() -> Definitions:
    return Definitions(
        columns=list(EXPECTED_COLUMNS),
        statuses=list(FALLBACK_STATUSES),
        subcategory_to_category={_norm_key(s): c for c, s in FALLBACK_CATEGORY_ROWS},
        subcategory_label={_norm_key(s): s for c, s in FALLBACK_CATEGORY_ROWS},
    )


def normalize_dump(
    df: pd.DataFrame,
    defs: Definitions,
    aliases: dict[str, str] | None = None,
) -> tuple[pd.DataFrame, LoadReport]:
    aliases = SUBCATEGORY_ALIASES if aliases is None else aliases
    alias_by_key = {_norm_key(k): v for k, v in aliases.items()}

    report = LoadReport(rows_in=len(df))
    report.missing_columns = [c for c in EXPECTED_COLUMNS if c not in df.columns]

    out = pd.DataFrame(index=df.index)
    out["comp_no"] = df.get("Comp. No.")
    out["category_raw"] = df.get("Category")
    out["sub_category_raw"] = df.get("Sub Category")

    # --- derived analysis category ---------------------------------------
    keys = out["sub_category_raw"].map(_norm_key)
    keys = keys.map(lambda k: _norm_key(alias_by_key[k]) if k in alias_by_key else k)

    out["sub_category"] = keys.map(defs.subcategory_label)
    out["category"] = keys.map(defs.subcategory_to_category)

    unmapped = out["category"].isna() & out["sub_category_raw"].notna()
    if unmapped.any():
        report.unmapped_subcategories = (
            out.loc[unmapped, "sub_category_raw"].value_counts().to_dict()
        )
    out["category"] = out["category"].fillna("Unmapped")
    out["sub_category"] = out["sub_category"].fillna(out["sub_category_raw"])
    out["recategorised"] = (
        out["category"].ne(out["category_raw"]) & out["category"].ne("Unmapped")
    )

    # --- zone / ward ------------------------------------------------------
    zw = df.get("Zone & Ward", pd.Series(index=df.index, dtype=object)).map(split_zone_ward)
    out["zone"] = [t[0] for t in zw]
    out["ward_name"] = [t[1] for t in zw]
    out["ward_no"] = pd.array([t[2] for t in zw], dtype="Int64")

    # --- people -----------------------------------------------------------
    for src, name_col, mob_col in (
        ("Complainer Name & Mob. No.", "complainant_name", "complainant_mobile"),
        ("Concern Person Name & Mob. No.", "officer_name", "officer_mobile"),
    ):
        parts = df.get(src, pd.Series(index=df.index, dtype=object)).map(split_name_mobile)
        out[name_col] = [t[0] for t in parts]
        out[mob_col] = [t[1] for t in parts]

    # --- dates ------------------------------------------------------------
    opened = pd.to_datetime(df.get("Date & Time"), format=DATE_FORMAT, errors="coerce")
    closed = pd.to_datetime(df.get("Date of Closure"), format=DATE_FORMAT, errors="coerce")
    out["opened_at"] = opened
    out["closed_at"] = closed
    report.unparsed_opened = int(opened.isna().sum())
    report.unparsed_closed = int(closed.isna().sum())

    out["resolution_hours"] = (closed - opened).dt.total_seconds() / 3600
    out.loc[out["resolution_hours"] < 0, "resolution_hours"] = pd.NA
    report.closed_before_opened = int(((closed - opened).dt.total_seconds() < 0).sum())

    # --- status -----------------------------------------------------------
    status = df.get("Status", pd.Series(index=df.index, dtype=object)).astype("string").str.strip()
    canonical = {_norm_key(s): s for s in defs.statuses}
    out["status"] = status.map(lambda s: canonical.get(_norm_key(s)))
    unknown = out["status"].isna() & status.notna()
    if unknown.any():
        report.unknown_statuses = status[unknown].value_counts().to_dict()
    out["status"] = out["status"].fillna(status)

    out["description"] = df.get("Description")
    report.rows_out = len(out)
    return out.reset_index(drop=True), report
