"""
Kanpur Nagar Nigam -- Grievance Dashboard (NCAP DSP)

Standalone Streamlit app. Data arrives as an XLSX/CSV export from the
complaints portal; category definitions are read live from the published
definitions sheet.

Run:  streamlit run app.py
"""

from __future__ import annotations

import pandas as pd
import plotly.express as px
import streamlit as st

from kanpur_normalize import (
    SHEET_PUB,
    Definitions,
    fallback_definitions,
    load_definitions,
    normalize_dump,
    read_upload,
)

CITY = "Kanpur"
STATUS_COLOURS = {
    "Pending": "#E4A11B",
    "Completed": "#14A44D",
    "Rejected": "#DC4C64",
    "Unmapped": "#9FA6B2",
}
CATEGORY_ORDER = ["Sanitation", "Engineering", "Malba", "Unmapped"]

st.set_page_config(
    page_title=f"{CITY} Grievance Dashboard",
    page_icon="🗂️",
    layout="wide",
)


# ------------------------------------------------------------------ data load

@st.cache_data(ttl=3600, show_spinner="Loading category definitions…")
def cached_definitions() -> tuple[Definitions, str | None]:
    """Master tables from the published sheet, with a local fallback."""
    try:
        return load_definitions(SHEET_PUB), None
    except Exception as exc:  # network down, sheet unpublished, tab renamed
        return fallback_definitions(), f"{type(exc).__name__}: {exc}"


@st.cache_data(show_spinner="Parsing dump…")
def cached_parse(data: bytes, filename: str, _defs_key: tuple):
    """Cached on the uploaded bytes, so a re-run of the same file is free."""
    defs, _ = cached_definitions()
    raw = read_upload(data, filename)
    return normalize_dump(raw, defs)


def fmt_hours(hours: float | None) -> str:
    if hours is None or pd.isna(hours):
        return "—"
    if hours < 48:
        return f"{hours:.1f} hrs"
    return f"{hours / 24:.1f} days"


# --------------------------------------------------------------------- header

st.title(f"{CITY} Nagar Nigam — Grievance Dashboard")
st.caption("NCAP Dispersed Sources Programme · air-quality grievance redressal")

defs, defs_error = cached_definitions()
if defs_error:
    st.warning(
        "Could not read the live definitions sheet — using the built-in "
        f"snapshot instead. Category mapping may be out of date. ({defs_error})"
    )

with st.sidebar:
    st.header("Data")
    upload = st.file_uploader(
        "Portal export",
        type=["xlsx", "xls", "csv"],
        help="Complaints List export. The banner row and blank first column "
             "are handled automatically.",
    )
    st.divider()
    st.caption(
        "Analysis categories are derived from **Sub Category** using the "
        "definitions sheet — not from the export's own Category column, "
        "which reports Malba tickets as Engineering."
    )

if upload is None:
    st.info("Upload a portal export in the sidebar to begin.")
    st.subheader("Categories in use")
    st.dataframe(
        pd.DataFrame(
            [
                {"Category": defs.subcategory_to_category[k],
                 "Sub category": defs.subcategory_label[k]}
                for k in defs.subcategory_to_category
            ]
        ).sort_values(["Category", "Sub category"]),
        hide_index=True,
        width="stretch",
    )
    st.stop()

defs_key = (tuple(sorted(defs.subcategory_to_category.items())), tuple(defs.statuses))
try:
    df_all, report = cached_parse(upload.getvalue(), upload.name, defs_key)
except Exception as exc:
    st.error(
        f"Could not parse **{upload.name}**. Check that it is an unmodified "
        f"portal export.\n\n`{type(exc).__name__}: {exc}`"
    )
    st.stop()

if df_all.empty:
    st.error("The file parsed successfully but contains no data rows.")
    st.stop()


# -------------------------------------------------------------- data quality

if not report.is_clean:
    with st.expander("⚠️ Data quality — needs attention", expanded=True):
        st.code(report.render(), language=None)
        if report.unmapped_subcategories:
            st.markdown(
                "**Unmapped sub-categories** are counted under `Unmapped` and "
                "excluded from category comparisons. Add them to the "
                "definitions sheet to bring them into the analysis."
            )
else:
    with st.expander("✅ Data quality — clean", expanded=False):
        st.code(report.render(), language=None)


# ------------------------------------------------------------------- filters

with st.sidebar:
    st.header("Filters")

    valid_dates = df_all["opened_at"].dropna()
    if not valid_dates.empty:
        lo, hi = valid_dates.min().date(), valid_dates.max().date()
        picked = st.date_input(
            "Raised between", value=(lo, hi), min_value=lo, max_value=hi
        )
        if isinstance(picked, tuple) and len(picked) == 2:
            date_from, date_to = picked
        else:
            date_from, date_to = lo, hi
    else:
        date_from = date_to = None

    def multi(label: str, column: str, order: list[str] | None = None):
        values = df_all[column].dropna().unique().tolist()
        if order:
            values = [v for v in order if v in values] + sorted(
                v for v in values if v not in order
            )
        else:
            values = sorted(values)
        return st.multiselect(label, values, default=values)

    sel_category = multi("Category", "category", CATEGORY_ORDER)
    sel_status = multi("Status", "status", defs.statuses)
    sel_zone = multi("Zone", "zone")

    ward_pool = df_all.loc[df_all["zone"].isin(sel_zone), "ward_name"]
    sel_ward = st.multiselect(
        "Ward",
        sorted(ward_pool.dropna().unique().tolist()),
        default=[],
        help="Leave empty for all wards in the selected zones.",
    )

mask = (
    df_all["category"].isin(sel_category)
    & df_all["status"].isin(sel_status)
    & (df_all["zone"].isin(sel_zone) | df_all["zone"].isna())
)
if sel_ward:
    mask &= df_all["ward_name"].isin(sel_ward)
if date_from is not None:
    mask &= (
        df_all["opened_at"].dt.date.between(date_from, date_to)
        | df_all["opened_at"].isna()
    )

df = df_all.loc[mask]

if df.empty:
    st.warning("No tickets match the current filters.")
    st.stop()


# ---------------------------------------------------------------------- KPIs

total = len(df)
by_status = df["status"].value_counts()
completed = int(by_status.get("Completed", 0))
pending = int(by_status.get("Pending", 0))
rejected = int(by_status.get("Rejected", 0))
median_res = df.loc[df["status"] == "Completed", "resolution_hours"].median()

pending_age = None
if pending:
    ref = df["opened_at"].max()
    ages = (ref - df.loc[df["status"] == "Pending", "opened_at"]).dt.total_seconds() / 3600
    pending_age = ages.median()

c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Total tickets", f"{total:,}")
c2.metric("Completed", f"{completed:,}", f"{completed / total:.0%} of total")
c3.metric("Pending", f"{pending:,}", f"{pending / total:.0%} of total")
c4.metric("Median time to close", fmt_hours(median_res))
c5.metric("Median age of pending", fmt_hours(pending_age))

st.divider()


# -------------------------------------------------------------------- charts

left, right = st.columns(2)

with left:
    st.subheader("Status by category")
    pivot = (
        df.groupby(["category", "status"]).size().reset_index(name="tickets")
    )
    fig = px.bar(
        pivot,
        x="category",
        y="tickets",
        color="status",
        color_discrete_map=STATUS_COLOURS,
        category_orders={
            "category": [c for c in CATEGORY_ORDER if c in pivot["category"].values],
            "status": defs.statuses,
        },
        text="tickets",
    )
    fig.update_layout(xaxis_title=None, yaxis_title="Tickets", legend_title=None)
    st.plotly_chart(fig, width="stretch")

with right:
    st.subheader("Tickets by zone")
    zone = (
        df.groupby(["zone", "status"], dropna=False)
        .size()
        .reset_index(name="tickets")
    )
    zone["zone"] = zone["zone"].fillna("(not recorded)")
    fig = px.bar(
        zone,
        x="tickets",
        y="zone",
        color="status",
        orientation="h",
        color_discrete_map=STATUS_COLOURS,
        category_orders={"status": defs.statuses},
    )
    fig.update_layout(
        yaxis_title=None,
        xaxis_title="Tickets",
        legend_title=None,
        yaxis={"categoryorder": "total ascending"},
    )
    st.plotly_chart(fig, width="stretch")

st.subheader("Sub-category breakdown")
sub = (
    df.groupby(["category", "sub_category"]).size().reset_index(name="tickets")
    .sort_values("tickets", ascending=True)
)
fig = px.bar(
    sub,
    x="tickets",
    y="sub_category",
    color="category",
    orientation="h",
    category_orders={"category": CATEGORY_ORDER},
)
fig.update_layout(yaxis_title=None, xaxis_title="Tickets", legend_title=None)
st.plotly_chart(fig, width="stretch")

st.subheader("Daily volume")
raised = (
    df.dropna(subset=["opened_at"])
    .assign(date=lambda d: d["opened_at"].dt.date)
    .groupby("date").size().rename("Raised")
)
closed = (
    df.dropna(subset=["closed_at"])
    .assign(date=lambda d: d["closed_at"].dt.date)
    .groupby("date").size().rename("Closed")
)
daily = pd.concat([raised, closed], axis=1).fillna(0).sort_index().reset_index()
if len(daily) > 1:
    fig = px.line(
        daily, x="date", y=["Raised", "Closed"], markers=True,
        color_discrete_map={"Raised": "#3B71CA", "Closed": "#14A44D"},
    )
    fig.update_layout(xaxis_title=None, yaxis_title="Tickets", legend_title=None)
    st.plotly_chart(fig, width="stretch")
else:
    st.caption("Daily trend needs more than one day of data.")

completed_rows = df[df["status"] == "Completed"].dropna(subset=["resolution_hours"])
if len(completed_rows) > 1:
    st.subheader("Time to closure")
    fig = px.histogram(
        completed_rows, x="resolution_hours", nbins=30, color="category",
        category_orders={"category": CATEGORY_ORDER},
    )
    fig.update_layout(
        xaxis_title="Hours to closure", yaxis_title="Tickets", legend_title=None
    )
    st.plotly_chart(fig, width="stretch")


# ------------------------------------------------------- ward table + audit

st.divider()
st.subheader("Ward performance")
ward = (
    df.assign(_done=df["status"].eq("Completed"))
    .groupby(["zone", "ward_no", "ward_name"], dropna=False)
    .agg(
        tickets=("comp_no", "size"),
        completed=("_done", "sum"),
        median_hours=("resolution_hours", "median"),
    )
    .reset_index()
)
ward["completion_rate"] = ward["completed"] / ward["tickets"]
st.dataframe(
    ward.sort_values("tickets", ascending=False),
    hide_index=True,
    width="stretch",
    column_config={
        "zone": "Zone",
        "ward_no": st.column_config.NumberColumn("Ward no.", format="%d"),
        "ward_name": "Ward",
        "tickets": st.column_config.NumberColumn("Tickets"),
        "completed": st.column_config.NumberColumn("Completed"),
        "completion_rate": st.column_config.ProgressColumn(
            "Completion", min_value=0, max_value=1, format="%.0f%%"
        ),
        "median_hours": st.column_config.NumberColumn(
            "Median hrs to close", format="%.1f"
        ),
    },
)

recat = df[df["recategorised"]]
if not recat.empty:
    with st.expander(
        f"Reclassified tickets ({len(recat)}) — export category vs analysis category"
    ):
        st.caption(
            "These arrived under a different Category in the export and were "
            "reassigned using the Sub Category mapping."
        )
        st.dataframe(
            recat[["comp_no", "category_raw", "category", "sub_category",
                   "zone", "ward_name", "status"]],
            hide_index=True,
            width="stretch",
        )

with st.expander(f"All filtered tickets ({len(df):,})"):
    st.dataframe(df, hide_index=True, width="stretch")

st.download_button(
    "Download cleaned data (CSV)",
    df.to_csv(index=False).encode("utf-8"),
    file_name=f"{CITY.lower()}_grievances_cleaned.csv",
    mime="text/csv",
)
